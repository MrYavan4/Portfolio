//Using veriables:
  
$(document).ready(function() {
   
    var hText = "This is just some Text";
    
    $("h1").click(function() {
       
        $("p").text(hText);
        
    });
    
});

//Using tages in veriables  
  
$(document).ready(function() {
   
    var hText = $("#head1").text();
    
    $("h1").click(function() {
       
        $("p").text(hText);
        
    });
    
});

//Combining Variables 

  
$(document).ready(function() {
   
    var hText = "This is just some Text";
    var text1 = "The heading text is";
    var text2 = text1 + hText;
    
    $("h1").click(function() {
       
        $("p").text(text2);
        
    });
    
});